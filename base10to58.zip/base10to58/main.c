#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main()
{
   char s[1000];
    FILE *fptr;
    if ((fptr = fopen("dsd.txt", "r")) == NULL) {

     exit(1);   }

    fscanf(fptr,"%[^\n]" , s);
    fclose(fptr);

    strrev(s);
    FILE*fp;
    fp = fopen("dsd2.txt", "w");

    if (fp == NULL) {
        printf("Error!");
        exit(1);
    }
    fprintf(fp, "%s", s);
    fclose(fp);
   printf("Reverse of the string: %s\n", s);
   return 0;
}

